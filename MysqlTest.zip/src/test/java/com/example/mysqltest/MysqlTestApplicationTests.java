package com.example.mysqltest;

import com.example.mysqltest.domain.User;
import com.example.mysqltest.mapper.UserMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class MysqlTestApplicationTests {

    @Autowired
    private UserMapper userMapper;
    @Test
    public void testFindAdll() {
        List<User> users = userMapper.findAll();
        System.out.println(users);
    }
    @Test
    void contextLoads() {
    }

}
