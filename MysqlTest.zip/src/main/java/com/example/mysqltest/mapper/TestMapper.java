package com.example.mysqltest.mapper;

import com.example.mysqltest.domain.Test;

import java.util.List;

public interface TestMapper {
    public List<Test> list();
}
