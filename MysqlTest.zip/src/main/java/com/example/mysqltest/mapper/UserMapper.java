package com.example.mysqltest.mapper;

import com.example.mysqltest.domain.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

@Mapper
@Repository
@Service
public interface UserMapper {
    @Select("select * from test")
    public List<User> findAll();
}
