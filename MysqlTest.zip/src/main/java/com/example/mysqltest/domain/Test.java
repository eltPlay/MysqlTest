package com.example.mysqltest.domain;

public class Test {
    private String userName;
    private int id;
    private String password;
    public String getUserName() {
        return userName;
    }

    public int getId() {
        return id;
    }

    public String getPassword() {
        return password;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Test() {
    }

    public Test(String userName, int id, String password) {
        this.userName = userName;
        this.id = id;
        this.password = password;
    }

    @Override
    public String toString() {
        return "User{" +
                "userName='" + userName + '\'' +
                ", id=" + id +
                ", password='" + password + '\'' +
                '}';
    }
}
